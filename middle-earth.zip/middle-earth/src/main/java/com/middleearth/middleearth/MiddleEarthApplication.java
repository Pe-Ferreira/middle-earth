package com.middleearth.middleearth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiddleEarthApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiddleEarthApplication.class, args);
	}
}
